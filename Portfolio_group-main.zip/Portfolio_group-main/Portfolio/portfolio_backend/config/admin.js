module.exports = ({ env }) => ({
  auth: {
    secret: env('ADMIN_JWT_SECRET', 'e6ee8a1a999c6f53bd0f5f22a4abe27d'),
  },
});
