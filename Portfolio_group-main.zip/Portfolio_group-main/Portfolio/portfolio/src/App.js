import React from "react";
import { Provider } from "react-redux";
import store from "./store.js";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Navbar1 from "./Components/Navbar"
import Main from "./Pages/Main"
import './index.css'




function App() {
  return (
    
   
      <div className="App" >
        <Routes>
         <Route path="/" element={<Main/>} exact />
        </Routes>
      </div>

 
  );
}

export default App;
