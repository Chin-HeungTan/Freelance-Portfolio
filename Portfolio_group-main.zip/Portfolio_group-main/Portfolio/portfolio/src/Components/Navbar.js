import React, { useState, useEffect } from "react";

import {
  MDBContainer,
  MDBNavbar,
  MDBNavbarBrand,
  MDBNavbarToggler,
  MDBIcon,
  MDBNavbarNav,
  MDBNavbarItem,
  MDBNavbarLink,
  MDBBtn,
  MDBDropdown,
  MDBDropdownToggle,
  MDBDropdownMenu,
  MDBDropdownItem,
  MDBDropdownLink,
  MDBCollapse
} from 'mdb-react-ui-kit';
import { connect } from "react-redux";
import Navbar from 'react-bootstrap/Navbar'
import Container from 'react-bootstrap/Container'
import Nav from 'react-bootstrap/Nav'
import '../Pages/style.css'


function Navbar1(){
    return(
        <>
      <MDBNavbar fixed='top'  dark bgColor='dark'  id="Navbar"  >
    <Container>
    <Navbar.Brand href="#home"> <>
      <MDBBtn tag='a' color='none' className='m-1' style={{ color: '#3b5998' }}>
        <MDBIcon fab icon='facebook-f' size='lg' />
      </MDBBtn>
      &nbsp;&nbsp;
      <MDBBtn tag='a' color='none' className='m-1' style={{ color: '#55acee' }}>
        <MDBIcon fab icon='twitter' size='lg' />
      </MDBBtn>
      &nbsp;&nbsp;
      <MDBBtn tag='a' color='none' className='m-1' style={{ color: '#ac2bac' }}>
        <MDBIcon fab icon='instagram' size='lg' />
      </MDBBtn>
    </></Navbar.Brand>
    <MDBNavbarNav right fullWidth={false} className='mb-2 mb-lg-0'>
    <Nav className="me-auto">
      <Nav.Link href="#home"><p>Home</p></Nav.Link>
      &nbsp;&nbsp;&nbsp;&nbsp;
      <Nav.Link href="#features"><p>Services</p></Nav.Link>
      &nbsp;&nbsp;&nbsp;&nbsp;
      <Nav.Link href="#pricing"><p>Workflow</p></Nav.Link>
      &nbsp;&nbsp;&nbsp;&nbsp;
       <Nav.Link href="#home"><p>Past Work</p></Nav.Link>
       &nbsp;&nbsp;&nbsp;&nbsp;
      <Nav.Link href="#features"><p>Technology</p></Nav.Link>
      &nbsp;&nbsp;&nbsp;&nbsp;
      <Nav.Link href="#pricing"><p>Teams</p></Nav.Link>
      &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;
      <Nav.Link href="#pricing" id ="Buttons"><h5 style={{color:"white"}}>Rates</h5></Nav.Link>
    </Nav>
    </MDBNavbarNav>
    </Container>
  </MDBNavbar>
  <br />

        </>
    )
}

export default (Navbar1);