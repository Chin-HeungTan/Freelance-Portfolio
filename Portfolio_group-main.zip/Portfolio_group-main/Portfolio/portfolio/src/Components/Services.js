import React, { useState, useEffect } from "react";

import { connect } from "react-redux";
import Navbar from 'react-bootstrap/Navbar'
import Container from 'react-bootstrap/Container'
import Nav from 'react-bootstrap/Nav'
import '../Pages/style.css'
import { MDBCard, MDBCardImage, MDBCardBody, MDBCardTitle, MDBCardText, MDBRow, MDBCol,MDBCardHeader, MDBCardFooter } from 'mdb-react-ui-kit';
import 'mdb-react-ui-kit/dist/css/mdb.min.css'
import { IoGitCommitOutline } from "react-icons/io5";
import image from "../Pages/Main.PNG"
import image1 from "../Pages/main2.PNG"
function Services(){
    return(
        <>
<div className="container">
  <div className="Row">
    <br></br>
    <h2 style={{textAlign:"center", color:"rgb(254 101 98)"}}>Ways We Can Help You <IoGitCommitOutline size="30"/></h2>
  </div>
  <br></br>
  <br></br>
  <div style={{marginLeft:"7%"}}>

    <div className="row">
      <div className="col-6">

      </div>
      <div className="col-6">
<img src=""></img>
      </div>
    </div>

    <div className="row">
      <div className="col-6">
<h4>1. Design and Create Beautiful Landing Pages</h4>
<br></br>
<p style={{fontSize:"20px"}}>You want a website. It must look great and you want it to work... All the time. <br></br>
  Well, that's why I'm here! I help you by designing, building, <br></br>and hosting a beautiful site that'll grow your business. Promise.</p>
      </div>
      <div className="col-6">
<img src={image} style={{width:"80%",height:"100%"}}></img>
      </div>
    </div>
<br></br>
<br></br>
<br></br>
    <div className="row">
      <div className="col-6">
      <img src={image1} style={{width:"80%",height:"100%"}}></img>
      </div>
      <div className="col-6">
      <br></br>
<br></br>
<br></br>
<br></br>
      <h4>2. Build Analytical Dashboard</h4>
      <br></br>
      <p style={{fontSize:"20px"}}>An impressive Google ranking means more people see your fantastic blog post or revolutionary product. 
       <br></br>I ensure you have a leading ranking with best SEO practices. Give your content the audience it deserves!.</p>
      </div>
    </div>
    <br></br>
<br></br>
<br></br>
<br></br>

    <div className="row">
      <div className="col-6">
      <br></br>
<br></br>
<h4>3. Create A E-Commerce Platform And Launch Your Brand</h4>
<br></br>
<p style={{fontSize:"20px"}}>You want a website. It must look great and you want it to work... All the time. <br></br>
  Well, that's why I'm here! I help you by designing, building, <br></br>and hosting a beautiful site that'll grow your business. Promise.</p>
      </div>
      <div className="col-6">
<img src={image} style={{width:"80%",height:"100%"}}></img>
      </div>
    </div>
    <br></br>
<br></br>
<br></br>
    <div className="row">
      <div className="col-6">
      <img src={image1} style={{width:"80%",height:"100%"}}></img>
      </div>
      <div className="col-6">
      <br></br>
<br></br>
<br></br>
<br></br>
      <h4>4. Develop Unique Front End Website For NFT And Cryptocurrency Applications</h4>
      <br></br>
      <p style={{fontSize:"20px"}}>An impressive Google ranking means more people see your fantastic blog post or revolutionary product. 
       <br></br>I ensure you have a leading ranking with best SEO practices. Give your content the audience it deserves!.</p>
      </div>
    </div>
   
    
  
    </div>
</div>

  <br />

        </>
    )
}

export default (Services);