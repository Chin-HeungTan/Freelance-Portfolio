import React, { useState, useEffect } from "react";

import { connect } from "react-redux";
import Container from 'react-bootstrap/Container'
import '../Pages/style.css'
import { MDBCard, MDBCardImage, MDBCardBody, MDBCardTitle, MDBCardText, MDBRow, MDBCol,MDBCardHeader, MDBCardFooter,MDBIcon,MDBBtn } from 'mdb-react-ui-kit';
import 'mdb-react-ui-kit/dist/css/mdb.min.css'
import { IoGitCommitOutline } from "react-icons/io5";
import ReactFlow from 'react-flow-renderer';

function Workflow(){
    const elements = [
        {
          id: '1',
          type: 'input', // input node
          data: { label: <div style={{color:"rgb(254 101 98)"}}><b>Free Consultation</b></div> },
          position: { x: 50, y: 25 },
        },
        // default node
        {
          id: '2',
          // you can also pass a React component as a label
          data: { label: <div style={{color:"rgb(254 101 98)"}}><b>Understanding Your Needs</b></div>  },
          position: { x: 200, y: 190 },
        },
        {
          id: '3',
          type: 'input', // output node
          data:{ label: <div style={{color:"rgb(254 101 98)"}}><b>Design Your Idea</b></div> },
          position: { x: 380, y: 25 },
        },
        {
          id: '4',
          // you can also pass a React component as a label
          data: { label: <div style={{color:"rgb(254 101 98)"}}><b>Prototype Proposal</b></div>  },
          position: { x: 580, y: 190 },
        },
        {
          id: '5',
          type: 'input', // output node
          data: { label:  <div style={{color:"rgb(254 101 98)"}}><b>Review & Adjustment</b></div>  },
          position: { x: 700, y: 25 },
        },
        // animated edge
        { id: 'e1-2', source: '1', target: '2', animated: true, arrowHeadType: 'arrowclosed' },
        { id: 'e2-3', source: '2', target: '3' ,animated: true, arrowHeadType: 'arrowclosed'},
        { id: 'e3-4', source: '3', target: '4' ,animated: true, arrowHeadType: 'arrowclosed'},
        { id: 'e4-5', source: '4', target: '5' ,animated: true, arrowHeadType: 'arrowclosed'},
      ];
      


    return(
        <>

<div style={{width:"80%",marginLeft:"10%"}}>
  <div className="Row">
    <br></br>
    <h2 style={{textAlign:"center", color:"rgb(254 101 98)"}}>Workflow <IoGitCommitOutline size="30"/></h2>
  </div>
  <br></br>
  <br></br>
  <br></br>
  <br></br>
  <div style={{marginLeft:"20%"}}>
  <div style={{ height:'300px' }}>
    <ReactFlow elements={elements} />
  </div>
    
</div>
<br></br>
<br></br>
<br></br>

</div>

<br></br>
  <br></br>
  <br />

  




        </>
    )
}

export default (Workflow);