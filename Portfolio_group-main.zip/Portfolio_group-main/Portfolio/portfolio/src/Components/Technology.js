import React, { useState, useEffect } from "react";

import { connect } from "react-redux";
import Navbar from 'react-bootstrap/Navbar'
import Container from 'react-bootstrap/Container'
import Nav from 'react-bootstrap/Nav'
import '../Pages/style.css'
import { MDBCard, MDBCardImage, MDBCardBody, MDBCardTitle, MDBCardText, MDBRow, MDBCol,MDBCardHeader, MDBCardFooter,MDBIcon,MDBBtn } from 'mdb-react-ui-kit';
import 'mdb-react-ui-kit/dist/css/mdb.min.css'
import { IoGitCommitOutline } from "react-icons/io5";
import image from "../Pages/Main.PNG"
import image1 from "../Pages/main2.PNG"
function Technology(){

const [selected,setSelected]= useState("Frontend")



    
    return(
        <>

<div className="container">
  <div className="Row">
    <br></br>
    <h2 style={{textAlign:"center", color:"rgb(254 101 98)"}}>Technology<IoGitCommitOutline size="30"/></h2>
  </div>
  <br></br>
  <br></br>
  <br></br>
 
  <div style={{width:"25%",marginLeft:"39%"}}>
  <div className="row">
  {selected == "Frontend" &&
  <>
         <div className="col-sm-6">
    
         <MDBBtn style={{backgroundColor:"rgb(254 101 98)"}} size="lg" onClick={() => { setSelected('Frontend') }}>
          Frontend
         </MDBBtn>
         </div>
         <div className="col-sm-6">
         <MDBBtn  outline color='' style={{borderColor:"rgb(254 101 98)",color:"white"}} size="lg" onClick={() => { setSelected('Backend') }}>
           Backend
         </MDBBtn>
         </div>
         </>
      }

{selected == "Backend" &&
  <>
         <div className="col-sm-6">
    
         <MDBBtn  outline color='' style={{borderColor:"rgb(254 101 98)",color:"white"}} size="lg" onClick={() => { setSelected('Frontend') }}>
          Frontend
         </MDBBtn>
         </div>
         <div className="col-sm-6">
         <MDBBtn  style={{backgroundColor:"rgb(254 101 98)"}} size="lg"  onClick={() => { setSelected('Backend') }}>
           Backend
         </MDBBtn>
         </div>
         </>
      }
    
  </div>
  </div>
  <br></br>
  <br></br>
  <br></br>
  <br></br>
  <br></br>
  <br></br>

  {selected == "Frontend" &&
  <>
         <div style={{marginLeft:"30%",width:"50%"}}>

<div className="row">
  <div className="col-4">
  <img src="https://img.icons8.com/external-justicon-lineal-color-justicon/64/000000/external-html-responsive-web-design-justicon-lineal-color-justicon.png"/>

  </div>
  <div className="col-4">
  <img src="https://img.icons8.com/external-soft-fill-juicy-fish/60/000000/external-css-coding-and-development-soft-fill-soft-fill-juicy-fish.png"/>

  </div>
  <div className="col-4">
  <img src="https://img.icons8.com/color/68/000000/adobe-illustrator--v1.png"/>

  </div>
</div>

</div>
<br></br>
<div>

</div>

<br></br>
<br></br>
<br></br>
<br></br>
<div style={{marginLeft:"37%",width:"35%"}}>

<div className="row">
<div className="col-6">
<img src="https://img.icons8.com/dusk/64/000000/javascript-logo.png"/>
</div>
<div className="col-6">
<img  style={{height:"80%"}} src="https://img.icons8.com/plasticine/100/000000/react.png"/>

</div>
</div>

</div>
         </>
      }

{selected == "Backend" &&
  <>
         <div style={{marginLeft:"30%",width:"50%"}}>

<div className="row">
  <div className="col-4">
  <img src="https://img.icons8.com/office/80/000000/sql.png"/>

  </div>
  <div className="col-4">
  <img src="https://img.icons8.com/stickers/80/000000/python.png"/>

  </div>
  <div className="col-4">
  <img src="https://img.icons8.com/color/80/000000/mongodb.png"/>
  </div>
</div>

</div>
<br></br>
<div>

</div>

<br></br>
<br></br>
<br></br>
<br></br>
<div style={{marginLeft:"37%",width:"35%"}}>

<div className="row">
<div className="col-6">
<img src="https://img.icons8.com/external-becris-flat-becris/80/000000/external-r-data-science-becris-flat-becris.png"/>
</div>
<div className="col-6">
<img src="https://img.icons8.com/fluency/80/000000/node-js.png"/>

</div>
</div>

</div>
         </>
      }
 
<br></br>



</div>

<br></br>
  <br></br>
  <br />

  
  <br></br>
  <br></br>
  <br />



        </>
    )
}

export default (Technology);