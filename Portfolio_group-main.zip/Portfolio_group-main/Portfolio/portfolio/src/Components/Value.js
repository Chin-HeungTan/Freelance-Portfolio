import React, { useState, useEffect } from "react";

import { connect } from "react-redux";
import Navbar from 'react-bootstrap/Navbar'
import Container from 'react-bootstrap/Container'
import Nav from 'react-bootstrap/Nav'
import '../Pages/style.css'
import { MDBCard, MDBCardImage, MDBCardBody, MDBCardTitle, MDBCardText, MDBRow, MDBCol,MDBCardHeader, MDBCardFooter,MDBIcon,MDBBtn } from 'mdb-react-ui-kit';
import 'mdb-react-ui-kit/dist/css/mdb.min.css'
import { IoGitCommitOutline } from "react-icons/io5";
import image from "../Pages/Main.PNG"
import image1 from "../Pages/main2.PNG"
function Value(){
    return(
        <>

<div className="container">
  <div className="Row">
    <br></br>
    <h2 style={{textAlign:"center", color:"rgb(254 101 98)"}}>Our Value Proposition <IoGitCommitOutline size="30"/></h2>
  </div>
  <br></br>
  <br></br>
  <br></br>
  <br></br>
  <div style={{marginLeft:"20%"}}>

    <div className="row">
      <div className="col-4">
      <MDBBtn size='lg' floating style={{ backgroundColor: 'rgb(254 101 98)' }} href='#'>
      <MDBIcon fas icon='cog' size="lg" />
    </MDBBtn>
    
      </div>
      <div className="col-4">
      <MDBBtn size='lg' floating style={{ backgroundColor: 'rgb(254 101 98)' }} href='#'>
      <MDBIcon fas icon='desktop' size="lg" />
    </MDBBtn>

      </div>
      <div className="col-4">
      <MDBBtn size='lg' floating style={{ backgroundColor: 'rgb(254 101 98)' }} href='#'>
      <MDBIcon fas icon='dollar-sign' size="lg"/>
    </MDBBtn>

      </div>
    </div>
  
    </div>
    <br></br>
    <div>
    <div className="row">
      <div className="col-4">
      <p style={{fontSize:"20px",marginLeft:"50%"}}>SEO Optimization</p>
    
      </div>
      <div className="col-4">
      <p style={{fontSize:"20px",marginLeft:"22%"}}>Fluid Web Application</p>

      </div>
      <div className="col-4">
      <p style={{fontSize:"20px"}}>Increase Conversion Rate </p>

      </div>
    </div>
    </div>

    <br></br>
    <br></br>
    <br></br>
    <br></br>
    <div style={{marginLeft:"20%"}}>

<div className="row">
  <div className="col-4">
  <MDBBtn size='lg' floating style={{ backgroundColor: 'rgb(254 101 98)' }} href='#'>
  <MDBIcon far icon='laugh-beam' size="lg" />
</MDBBtn>

  </div>
  <div className="col-4">
  <MDBBtn size='lg' floating style={{ backgroundColor: 'rgb(254 101 98)' }} href='#'>
  <MDBIcon fas icon='ad' size="lg" />
</MDBBtn>

  </div>
  <div className="col-4">
  <MDBBtn size='lg' floating style={{ backgroundColor: 'rgb(254 101 98)' }} href='#'>
  <MDBIcon fas icon='database' size="lg"/>
</MDBBtn>

  </div>
</div>

</div>
<br></br>
<div>
<div className="row">
  <div className="col-4">
  <p style={{fontSize:"20px",marginLeft:"50%"}}>Sentimental Analysis</p>

  </div>
  <div className="col-4">
  <p style={{fontSize:"20px",marginLeft:"25%"}}>Marketing Analysis</p>

  </div>
  <div className="col-4">
  <p style={{fontSize:"20px",marginLeft:"10%"}}>Database Solution</p>

  </div>
</div>
</div>


</div>

<br></br>
  <br></br>
  <br />

  
  <br></br>
  <br></br>
  <br />



        </>
    )
}

export default (Value);