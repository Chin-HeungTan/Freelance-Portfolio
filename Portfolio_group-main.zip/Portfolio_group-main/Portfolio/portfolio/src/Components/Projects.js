import React, { useState, useEffect } from "react";

import { connect } from "react-redux";
import Container from 'react-bootstrap/Container'
import '../Pages/style.css'
import { MDBCard, MDBCardImage, MDBCardBody, MDBCardTitle, MDBCardText, MDBRow, MDBCol,MDBCardHeader, MDBCardFooter,MDBIcon,MDBBtn } from 'mdb-react-ui-kit';
import 'mdb-react-ui-kit/dist/css/mdb.min.css'
import { IoGitCommitOutline } from "react-icons/io5";
import ReactFlow from 'react-flow-renderer';

function Projects(){


    return(
        <>

<div className="container">
  <div className="Row">
    <br></br>
    <h2 style={{textAlign:"center", color:"rgb(254 101 98)"}}>Projects<IoGitCommitOutline size="30"/></h2>
  </div>
  <br></br>
  <br></br>
  <br></br>
  <div className="row">
  <div className="col-sm-6">
<div class="card bg-dark text-white" style={{width:"70%",height:"10%",marginLeft:"25%"}}>
  <img src="https://i.pinimg.com/originals/ea/19/55/ea1955079e3fdcaa1b59d1bba74433ba.jpg" class="card-img" alt="Stony Beach"/>
  <div class="card-img-overlay">
    <h5 class="card-title">Card title</h5>
    <p class="card-text">
      This is a wider card with supporting text below as a natural lead-in to additional
      content. This content is a little bit longer.
    </p>
    <p class="card-text">Last updated 3 mins ago</p>
  </div>
</div>
</div>
<div className="col-sm-6">
<div class="card bg-dark text-white" style={{width:"66%",height:"8%",marginLeft:""}}>
  <img src="https://news.artnet.com/app/news-upload/2021/10/Beeple-b.-1981-HUMAN-ONE-still_2.jpg" class="card-img" alt="Stony Beach"/>
  <div class="card-img-overlay">
    <h5 class="card-title">Card title</h5>
    <p class="card-text">
      This is a wider card with supporting text below as a natural lead-in to additional
      content. This content is a little bit longer.
    </p>
    <p class="card-text">Last updated 3 mins ago</p>
  </div>
</div>
</div>
  </div>


 

</div>

<br></br>
  <br></br>
  <br />

  




        </>
    )
}

export default (Projects);