// import {createStore,applyMiddleware,compose} from 'redux';
// import {composeWithDevTools} from 'redux-devtools-extension'
// import thunk from 'redux-thunk'
// import rootReducer from './Reducers/index.js'

// const initialState ={};
// const middleware = [thunk];

// const store = createStore(
//     rootReducer,
//     initialState,
//   compose(
//     applyMiddleware(thunk)
//     )
//   );
// export default store