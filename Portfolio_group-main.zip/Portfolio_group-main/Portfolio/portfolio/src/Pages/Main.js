
   
import React, { useState, useEffect } from "react";

import { MDBBtn, MDBCard, MDBCardTitle, MDBCardText, MDBCardBody, MDBCardHeader, MDBCardFooter,MDBCardImage} from 'mdb-react-ui-kit';
import "./style.css";
import { connect } from "react-redux";
import Navbar1 from "../Components/Navbar";
import image from "../Pages/Main.PNG"
import { HiChevronDoubleDown } from "react-icons/hi";
import styled, { keyframes } from 'styled-components';
import { bounce } from 'react-animations';
import Services from '../Components/Services';
import Value from '../Components/Value'
import Workflow from '../Components/Workflow'
import Projects from '../Components/Projects'
import Technology from "../Components/Technology";
function Main(){
    const Bounce = styled.div`animation: 2s ${keyframes `${bounce}`} infinite`;
    console.log("hello")
    return(
        < >
        <Navbar1/>
    
      <div className="Main">
      <br></br>
      <br></br>
      <br></br>
      <br></br>
      <br></br>
      <br></br>
      <div className="container2">
            
            <div class="row">
           <div class="col-sm-6">
           <div style={{marginLeft:"33%"}}>
           <h3>Hi There <img src="https://whatemoji.org/wp-content/uploads/2020/07/Waving-Hand-Emoji.png" style={{width:"10%",height:"10%"}}></img> &nbsp;We're</h3>
            
           <br></br>
           <h3 style={{color:"rgb(254 101 98)",fontSize:"33px"}}>Web Developers + Designers + Data Specialist </h3>
           <br></br>
           <br></br>
            <p>Helping people to turn their ideas into<br></br>
sites & apps that work.
Professional and Cost-Effective.
<br></br>
Always.</p>
<br></br>
<br></br>
      <br></br>
<MDBBtn  color='' size="lg" style={{width:"30%",height:"12%",backgroundColor:"rgb(254 101 98)"}} >
       Hire Us
      </MDBBtn>
      &nbsp;
      &nbsp;
      &nbsp;
      <MDBBtn outline color='' size="lg" style={{width:"30%",height:"12%",borderColor:"rgb(254 101 98)",color:"white"}} >
       View Services
      </MDBBtn>
      </div>
      </div>
      <div class="col-sm-6">
               
               <img src={image} style={{marginTop:"1%",height:"85%",width:"60%"}}></img>
           
                    
                 </div>
           </div>
    
       <br></br>
<br></br>

<p style={{textAlign:"center",fontSize:"20px"}}>Scroll For More</p>
<Bounce> <HiChevronDoubleDown style={{color:"white",marginLeft:"49%"}} size={40}/></Bounce>
       </div>
       <br></br>
<br></br>
<br></br>
<Services/>
<br></br>
<br></br>
<Value/>
<Workflow/>
<Projects/>
<Technology/>
      </div>

        </>
    )
}

export default (Main);
